package shifoo.com.app.modules.chooseheros.view;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Point;
import android.graphics.Typeface;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.TypedValue;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ExpandableListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oku.app.R;
import shifoo.com.app.Models.CelebrityMoreInfoModel;
import shifoo.com.app.Models.chooseHeroesModel;
import shifoo.com.app.apppreferences.AppPreferences;
import shifoo.com.app.base.activity.BaseActivity;
import shifoo.com.app.library.HostUrl;
import shifoo.com.app.library.LibFunction;
import shifoo.com.app.modules.home.view.HomeActivity;

public class CelebrityMoreInfoActivity extends BaseActivity {

    private ExpandableListView expandableListView;

    private ExpandableListViewAdapter expandableListViewAdapter;

    private List<String> listDataGroup;
    private HashMap<String, List<PersonalityItemDetail>> listDataChild;


    String mHeroId;

    CollapsingToolbarLayout collapsingToolbarLayout;


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_celebrity_more_info);

        mAppPrefrences = AppPreferences.INSTANCE;
        mAppPrefrences.initAppPreferences(getApplicationContext());

        expandableListView=findViewById(R.id.expandableListView);


        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.mipmap.ic_back_image);
        collapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        try {
            collapsingToolbarLayout.setTitle("");
            collapsingToolbarLayout.setCollapsedTitleTextColor(getResources().getColor(R.color.transperent));
        } catch (Exception e) {
            e.printStackTrace();
        }
        collapsingToolbarLayout.setExpandedTitleColor(getResources().getColor(R.color.colorPrimaryDark)); // transperent color = #00000000

        // finds id's
        TextView mUserProfilename = findViewById(R.id.user_profile_name);
        TextView mUserProfileShortBio = findViewById(R.id.user_profile_short_bio);
        TextView mTxtFans = findViewById(R.id.txt_fans);
        TextView mTxtwords = findViewById(R.id.txt_words);

        // fonts use here
        Typeface Celebrity = Typeface.createFromAsset(getAssets(),
                "fonts/JosefinSans_Bold.ttf");
        mUserProfileShortBio.setTypeface(Celebrity);
        mTxtFans.setTypeface(Celebrity);
        mTxtwords.setTypeface(Celebrity);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            mHeroId = extras.getString("hero_id");
            String hero_name = extras.getString("hero_name");
            String hero_profession = extras.getString("hero_profession");
            String fans_count = extras.getString("fans_count");
            mUserProfilename.setText(hero_name);
            mUserProfileShortBio.setText(hero_profession);
            mTxtFans.setText(fans_count);


        }

        // initializing the objects
        initObjects();


        try {
            showHideProgressDialog(true);
            JSONObject loginJson = new JSONObject();
            // loginJson.put("catId", "1");
            loginJson.put("hero_id", 1);
            getHeroesProfile(HostUrl.BaseUrl + "hero/getHeroProfile", loginJson);
        } catch (Exception je) {

        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        expandableListView.setIndicatorBounds(expandableListView.getRight() - 40, expandableListView.getWidth());
    }

    private void initObjects() {

        // initializing the list of groups
        listDataGroup = new ArrayList<>();

        // initializing the list of child
        listDataChild = new HashMap<>();

        // initializing the adapter object
        expandableListViewAdapter = new ExpandableListViewAdapter(this, listDataGroup, listDataChild);

        // setting list adapter
        expandableListView.setAdapter(expandableListViewAdapter);

    }


    public void getHeroesProfile(String urlOne, JSONObject jsonObject) {

        // System.out.println("Auth key  " + auth_key);
        try {

            System.out.println(urlOne);

            System.out.println("json Category of  Heroes" + jsonObject);
            JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                    urlOne, jsonObject,
                    new Response.Listener<JSONObject>() {

                        @Override
                        public void onResponse(JSONObject response) {
                            System.out.println("Get Category By Id Response " + response);
                            showHideProgressDialog(false);

                            try {
                                JSONObject jb1 = response.getJSONObject("meta");
                                int code = jb1.getInt("code");
                                if (code == 200) {


                                    JSONArray jsonArray = response.getJSONArray("Data");

                                    setProfileData(jsonArray);


                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                        }
                    }, new Response.ErrorListener() {


                @Override
                public void onErrorResponse(VolleyError error) {
                    showHideProgressDialog(false);
                    System.out.println("12Error" + error.toString());
                    try {
                        if (error instanceof NetworkError) {
                            // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                        } else if (error instanceof NoConnectionError) {
                            // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                        } else if (error.networkResponse.data != null) {
                            String body = new String(error.networkResponse.data, "UTF-8");
                            //////println("response from server ///" + body);


                            JSONObject obj = new JSONObject(body);
                            JSONObject meta = obj.getJSONObject("meta");
                            String messgae = meta.getString("message");

                        } else {
                        }

                    } catch (Exception e) {
                        Toast.makeText(CelebrityMoreInfoActivity.this, "Server Error", Toast.LENGTH_SHORT).show();

                        //DialogNScableApp.callDialog("Error", MessagesAccess.serverError, PaymentHistoryActivity.this);
                        e.printStackTrace();
                    }
                }
            }) {

                @Override
                protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                    return super.parseNetworkResponse(response);
                }

                /**
                 * Passing some request headers
                 */
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    headers.put("Auth-Key", "");
                    return headers;
                }
            };

            // Wait 30 seconds and don't retry more than once
            jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(15000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            jsonObjReq.setShouldCache(true);
            RequestQueue queue = Volley.newRequestQueue(CelebrityMoreInfoActivity.this);
            queue.add(jsonObjReq);

        } catch (Exception e) {

            e.printStackTrace();
        }


    }


    private void setProfileData(JSONArray moreinfoarray) throws JSONException {

        try {
            for (int i = 0; i < moreinfoarray.length(); i++) {
                JSONObject jsonObject = moreinfoarray.getJSONObject(i);
                listDataGroup.add(jsonObject.getString("section_title"));

                List<PersonalityItemDetail> itemDetails = new ArrayList<>();

                JSONArray jsonArray = jsonObject.optJSONArray("row_data");
                if (jsonArray == null) {
                    PersonalityItemDetail personalityItemDetail = new PersonalityItemDetail();
                    personalityItemDetail.setValue(jsonObject.getString("section_description"));
                    itemDetails.add(personalityItemDetail);
                } else {
                    for (int j = 0; j < jsonArray.length(); j++) {
                        JSONObject childJsonObject = jsonArray.getJSONObject(j);
                        PersonalityItemDetail personalityItemDetail = new PersonalityItemDetail();
                        personalityItemDetail.setHeader(childJsonObject.getString("row_name"));
                        personalityItemDetail.setValue(childJsonObject.getString("row_value"));
                        itemDetails.add(personalityItemDetail);
                    }
                }


                listDataChild.put(jsonObject.getString("section_title"), itemDetails);

            }

            // notify the adapter
            expandableListViewAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
