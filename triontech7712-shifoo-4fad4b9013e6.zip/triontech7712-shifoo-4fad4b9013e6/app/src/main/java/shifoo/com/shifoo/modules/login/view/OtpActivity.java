package shifoo.com.shifoo.modules.login.view;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.ImageFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.goodiebag.pinview.Pinview;

import shifoo.com.shifoo.R;

public class OtpActivity extends AppCompatActivity {

TextView TV1,TV2,TV3,TV4,TextResend;


    Pinview pinview;
    Button otpProceed;
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);

        //find view's id
        otpProceed=(Button)findViewById(R.id.otpreceived);
        TV1 = (TextView) findViewById(R.id.otpheader);
        TV2 = (TextView) findViewById(R.id.otpheader2);
      //  TV3 = (TextView) findViewById(R.id.otpheader3);
        TV4 = (TextView) findViewById(R.id.otpheader4);
        TextResend = (TextView) findViewById(R.id.txt_resend);

        pinview=findViewById(R.id.mypinview);

        pinview.setPinViewEventListener(new Pinview.PinViewEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onDataEntered(Pinview pinview, boolean fromUser) {
                otpProceed.setBackground(getDrawable(R.drawable.round));
                otpProceed.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i= new Intent(OtpActivity.this,RegisterNameActivity.class);
                        startActivity(i);
                    }
                });



                // Toast.makeText(OtpActivity.this, pinview.getValue(), Toast.LENGTH_SHORT).show();
            }
        });


// type faces
        Typeface f = Typeface.createFromAsset(getAssets(),
                "fonts/JosefinSans_Bold.ttf");
        TV1.setTypeface(f);
        TV2.setTypeface(f);
      //  TV3.setTypeface(f);
        TV4.setTypeface(f);
        otpProceed.setTypeface(f);
        TextResend.setTypeface(f);





        TextResend.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                TextResend.setTextColor(getResources().getColorStateList(R.color.black));            }
        });


    }

}
