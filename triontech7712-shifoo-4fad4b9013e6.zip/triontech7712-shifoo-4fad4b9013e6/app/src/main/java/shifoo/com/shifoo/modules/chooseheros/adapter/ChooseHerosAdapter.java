package shifoo.com.shifoo.modules.chooseheros.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import shifoo.com.shifoo.R;
import shifoo.com.shifoo.modules.chooseheros.view.AboutCelebrityActivity;

public class ChooseHerosAdapter extends RecyclerView.Adapter<ChooseHerosAdapter.MyViewHolder> {
    private String [] data1;
    private String [] data2;
    TextView Name, Designation;

    //  private String [] data3 ;

    public  ChooseHerosAdapter(String []data1,String []data2)
    {
        this.data1=data1;
        this.data2=data2;
       // this.data3=data3;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).
                inflate(R.layout.row_chooseheros, viewGroup, false);


        return new ChooseHerosAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int position) {
        String name=data1[position];
        myViewHolder.Name.setText(name);
        String rnk=data2[position];
        myViewHolder.Designation.setText(rnk);
        /*String wrk=data3[position];
        myViewHolder.imageView.setText(wrk);*/

    }

    @Override
    public int getItemCount() {
        return data1.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView Name, Designation;
        private Context context;
        ImageView imageView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            context = itemView.getContext();

            Name = itemView.findViewById(R.id.txt_name);
            Designation = itemView.findViewById(R.id.txt_designation);
            imageView=itemView.findViewById(R.id.image);
            Typeface adapterTypeFace = Typeface.createFromAsset(itemView.getContext().getAssets(), "fonts/JosefinSans_Bold.ttf");
            this.Name.setTypeface(adapterTypeFace);
            this.Designation.setTypeface(adapterTypeFace);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(context, AboutCelebrityActivity.class);
                    context.startActivity(i);
                }
            });
        }
    }
}
