package shifoo.com.app.modules.cardviewquiz.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import oku.app.R;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import shifoo.com.app.Models.GetHeroesModel;
import shifoo.com.app.Models.QuizCardsModel;
import shifoo.com.app.base.activity.BaseActivity;
import shifoo.com.app.library.HostUrl;

import shifoo.com.app.modules.chooseheros.view.AboutCelebrityActivity;

public class QuizMainActivity extends BaseActivity {
    VerticalViewPager verticalViewPager;
    private String mHeroId;
    private ArrayList<QuizCardsModel> quizCardsModels;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_quiz_main);

        verticalViewPager = findViewById(R.id.verticleViewPager);
        verticalViewPager.setAdapter(new VerticlePagerAdapter(this));

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarquiz);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setElevation((float) 10.0);
        ImageView Imageviewback = findViewById(R.id.imageViewback);
        Imageviewback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(QuizMainActivity.this, AboutCelebrityActivity.class);
                startActivity(i);
            }
        });


        try {
            showHideProgressDialog(true);
            JSONObject loginJson = new JSONObject();
            loginJson.put("topic_id", "1");
            loginJson.put("hero_id", "1");
            getQuizByHeroId(HostUrl.BaseUrl + "hero/getCards", loginJson);

        } catch (Exception je) {

        }


       /* List<Fragment> list = new ArrayList<>();
        list.add(new ContentImageTextFragment());
        list.add(new TextContentFragment());
        list.add(new ContentVedioTextFragment());
        list.add(new ContentTextTypeFragment());
        list.add(new RateToipcFRagment());
        list.add(new CongratulationFragment());
       *//* list.add(new MCQFirstFragment());
        list.add(new StaggeredDataFragment());
        list.add(new QuizTrueFalseFragment());
*//*

        verticalViewPager = findViewById(R.id.viewPager);
        pagerAdapter = new VerticlePagerAdapter(getSupportFragmentManager(), list);
        verticalViewPager.setAdapter(pagerAdapter);
*/
    }

    private void setData() {
    }


    public void getQuizByHeroId(String urlOne, JSONObject jsonObject) {

        // System.out.println("Auth key  " + auth_key);
        try {

            System.out.println(urlOne);

            System.out.println("json Category of  Heroes" + jsonObject);
            JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                    urlOne, jsonObject,
                    response -> {
                        System.out.println("Get Category By Id Response " + response);
                        showHideProgressDialog(false);

                        try {
                            JSONObject jb1 = response.getJSONObject("meta");
                            int code = jb1.getInt("code");
                            if (code == 200) {

                                JSONArray jsonObject1 = response.getJSONArray("Data");


                            }


                        } catch (JSONException je) {
                            je.printStackTrace();
                        }
                        try {


                        } catch (Exception e) {
                            e.printStackTrace();
                        }


                    }, error -> {
                showHideProgressDialog(false);
                System.out.println("12Error" + error.toString());
                try {
                    if (error instanceof NetworkError) {
                        // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                    } else if (error instanceof NoConnectionError) {
                        // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                    } else if (error.networkResponse.data != null) {
                        String body = new String(error.networkResponse.data, "UTF-8");
                        //////println("response from server ///" + body);


                        JSONObject obj = new JSONObject(body);
                        JSONObject meta = obj.getJSONObject("meta");
                        String messgae = meta.getString("message");



                    } else {
                        //  DialogNScableApp.callDialog("Error", MessagesAccess.serverError, PaymentHistoryActivity.this);
                    }

                } catch (Exception e) {
                    Toast.makeText(QuizMainActivity.this, "Server Error", Toast.LENGTH_SHORT).show();

                    //DialogNScableApp.callDialog("Error", MessagesAccess.serverError, PaymentHistoryActivity.this);
                    e.printStackTrace();
                }
            }) {

                @Override
                protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                    return super.parseNetworkResponse(response);
                }

                /**
                 * Passing some request headers
                 */
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    headers.put("Auth-Key", "");
                    return headers;
                }
            };

            // Wait 30 seconds and don't retry more than once
            jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(15000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            jsonObjReq.setShouldCache(true);
            RequestQueue queue = Volley.newRequestQueue(QuizMainActivity.this);
            queue.add(jsonObjReq);

        } catch (Exception e) {

            e.printStackTrace();
        }


    }

}
