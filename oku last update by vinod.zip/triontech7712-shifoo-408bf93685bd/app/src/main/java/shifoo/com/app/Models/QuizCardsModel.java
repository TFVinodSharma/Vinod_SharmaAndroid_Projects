package shifoo.com.app.Models;

public class QuizCardsModel {

    private String hero_card_id = "";
    private String hero_id = "";
    private String card_topic_id = "";
    private String card_type = "";
    private String card_title = "";
    private String card_description = "";

    private String timestamp = "";
    private String card_source = "";
    private String card_time = "";
    private String card_sort_order = "";
    private String card_link = "";
    private String created_by = "";

    private String updated_by = "";
    private String created_at = "";
    private String updated_at = "";


    public String getHero_card_id() {
        return hero_card_id;
    }

    public void setHero_card_id(String hero_card_id) {
        this.hero_card_id = hero_card_id;
    }

    public String getHero_id() {
        return hero_id;
    }

    public void setHero_id(String hero_id) {
        this.hero_id = hero_id;
    }

    public String getCard_topic_id() {
        return card_topic_id;
    }

    public void setCard_topic_id(String card_topic_id) {
        this.card_topic_id = card_topic_id;
    }

    public String getCard_type() {
        return card_type;
    }

    public void setCard_type(String card_type) {
        this.card_type = card_type;
    }

    public String getCard_title() {
        return card_title;
    }

    public void setCard_title(String card_title) {
        this.card_title = card_title;
    }

    public String getCard_description() {
        return card_description;
    }

    public void setCard_description(String card_description) {
        this.card_description = card_description;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getCard_source() {
        return card_source;
    }

    public void setCard_source(String card_source) {
        this.card_source = card_source;
    }

    public String getCard_time() {
        return card_time;
    }

    public void setCard_time(String card_time) {
        this.card_time = card_time;
    }

    public String getCard_sort_order() {
        return card_sort_order;
    }

    public void setCard_sort_order(String card_sort_order) {
        this.card_sort_order = card_sort_order;
    }

    public String getCard_link() {
        return card_link;
    }

    public void setCard_link(String card_link) {
        this.card_link = card_link;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public String getUpdated_by() {
        return updated_by;
    }

    public void setUpdated_by(String updated_by) {
        this.updated_by = updated_by;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }
}
