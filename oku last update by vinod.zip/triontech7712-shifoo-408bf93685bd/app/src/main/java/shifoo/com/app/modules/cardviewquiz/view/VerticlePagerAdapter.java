package shifoo.com.app.modules.cardviewquiz.view;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import oku.app.R;
import shifoo.com.app.Models.GetHeroesModel;
import shifoo.com.app.Models.QuizCardsModel;

class VerticlePagerAdapter extends PagerAdapter {


    private ArrayList<QuizCardsModel> quizCardsModels;
    String mResources[] = {"To start off lets understand what exactly Android CardView is? " +
            "Its a new widget for Android, which can be used to display a card sort of " +
            "a layout in android. As you may know Android material design is inspired from paper " +
            "and ink concept. Mostly it displays views on top of each other, with shadows. In simple terms," +
            " Android CardView is such a view which has all material design properties, most importantly showing" +
            " shadows according the elevation. The best part about this view is that it extends FrameLayout and it" +
            " can be displayed on all the platforms of android since it’s available through the Support v7 library." +
            " Lets have a look at some of its properties:","To start off lets understand what exactly Android CardView is?" +
            " Its a new widget for Android, which can be used to display a card sort of a layout in android." +
            " As you may know Android material design is inspired from paper and ink concept. Mostly " +
            "it displays views on top of each other, with shadows. In simple terms, Android CardView " +
            "is such a view which has all material design properties, most importantly showing " +
            "shadows according the elevation. The best part about this view is that it extends " +
            "FrameLayout and it can be displayed on all the platforms of android since it’s available through the Support v7 " +
            "library. Lets have a look at some of its properties:"};
    //int[] logo={R.drawable.images};
    Context mContext;
    LayoutInflater mLayoutInflater;

    public VerticlePagerAdapter(Context context) {
        mContext = context;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mResources.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((LinearLayout) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        //final QuizCardsModel subsItem = quizCardsModels.get(position);
        View itemView = mLayoutInflater.inflate(R.layout.row_content_view_pager, container, false);

        TextView card_Title = (TextView) itemView.findViewById(R.id.card_title);
        TextView card_Description = (TextView) itemView.findViewById(R.id.card_description);
        ImageView card_Image=itemView.findViewById(R.id.card_image);


        card_Title.setText(mResources[position]);
        //card_Title.setText(subsItem.getCard_title());
       // card_Description.setText(subsItem.getCard_description());
       // card_Image.setImageResource(subsItem.getCard_source());
        container.addView(itemView);



        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }
}

