package shifoo.com.app.modules.chooseheros.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

//import com.getbase.floatingactionbutton.FloatingActionsMenu;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.JsonArray;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import oku.app.R;
import shifoo.com.app.Models.GetHeroesModel;
import shifoo.com.app.Models.chooseHeroesModel;
import shifoo.com.app.apppreferences.AppPreferences;
import shifoo.com.app.base.activity.BaseActivity;
import shifoo.com.app.library.HostUrl;
import shifoo.com.app.modules.chooseheros.fragment.FavoriteFragment;
import shifoo.com.app.modules.chooseheros.fragment.FiveFragment;
import shifoo.com.app.modules.chooseheros.fragment.FourFragment;
import shifoo.com.app.modules.chooseheros.fragment.NewsFragment;
import shifoo.com.app.modules.chooseheros.fragment.PopularFragment;
import shifoo.com.app.modules.chooseheros.fragment.SixFragment;
import shifoo.com.app.modules.home.view.FAQActivity;
import shifoo.com.app.modules.home.view.HomeActivity;
import shifoo.com.app.modules.login.view.LoginActivity;
import shifoo.com.app.modules.login.view.OtpActivity;

public class AboutCelebrityActivity extends BaseActivity {

    CollapsingToolbarLayout collapsingToolbarLayout;
    String mHeroId;
    ViewPager mViewPager;
    TabLayout mTabLay;
    ArrayList<GetHeroesModel> getHeroesModels;
     int mClickPos;
    Context mContext;



    ImageLoader imageLoader = ImageLoader.getInstance();
    ImageLoadingListener imageListener;
    DisplayImageOptions options;

    private static class ImageDisplayListener extends
            SimpleImageLoadingListener {

        static final List<String> displayedImages = Collections
                .synchronizedList(new LinkedList<String>());

        @Override
        public void onLoadingComplete(String imageUri, View view,
                                      Bitmap loadedImage) {
            if (loadedImage != null) {
                ImageView imageView = (ImageView) view;
                boolean firstDisplay = !displayedImages.contains(imageUri);
                if (firstDisplay) {
                    FadeInBitmapDisplayer.animate(imageView, 500);
                    displayedImages.add(imageUri);
                }
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // for full size of image in status bar
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.mipmap.ic_back_image);

        collapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);

        try {
            collapsingToolbarLayout.setTitle(getResources().getString(R.string.app_name));
            collapsingToolbarLayout.setCollapsedTitleTextColor(getResources().getColor(R.color.grey));
        } catch (Exception e) {
            e.printStackTrace();
        }
        collapsingToolbarLayout.setExpandedTitleColor(getResources().getColor(R.color.colorPrimaryDark)); // transperent color = #00000000

        try {


            options = new DisplayImageOptions.Builder()
                    .cacheInMemory()

                    .cacheOnDisc().build();
            imageListener = new ImageDisplayListener();
            imageLoader = ImageLoader.getInstance();
            imageLoader.init(ImageLoaderConfiguration.createDefault(mContext));


            ////////System.out.println(userLoginDetails);
        } catch (Exception e) {
            e.printStackTrace();
        }


        // appbar = (AppBarLayout) findViewById(R.id.appbar);
        TextView TxtNameOfCelebrity = findViewById(R.id.txtNameOfCelebrity);
        TextView TxtDesgCelebrity = findViewById(R.id.txtDesgCelebrity);
        ImageView heroIv = findViewById(R.id.hero_iv);

        Typeface About = Typeface.createFromAsset(getAssets(),
                "fonts/JosefinSans_Bold.ttf");
        TxtNameOfCelebrity.setTypeface(About);
        TxtDesgCelebrity.setTypeface(About);



        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            mHeroId = extras.getString("hero_id");
            String hero_name = extras.getString("hero_name");
            String hero_profession = extras.getString("hero_profession");
            String hero_short_desc = extras.getString("hero_short_desc");
            String hero_cover_photo = extras.getString("cover_photo");

            TxtNameOfCelebrity.setText(hero_name);
            TxtDesgCelebrity.setText(hero_profession);


            ImageAware imageAware = new ImageViewAware(heroIv, false);
            imageLoader.displayImage(hero_cover_photo, imageAware, options);
            // TxtNameOfCelebrity.setText(hero_name);

        }


        LinearLayout Btn_MoreInfo = findViewById(R.id.btn_moreinfo);
        Btn_MoreInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // final GetHeroesModel subsItem = getHeroesModels.get(mClickPos);
                // Toast.makeText(AboutCelebrityActivity.this, "hello", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(AboutCelebrityActivity.this, CelebrityMoreInfoActivity.class);
                i.putExtra("hero_id", mHeroId);
               /* i.putExtra("hero_name", subsItem.getHero_name());
                i.putExtra("hero_profession", subsItem.getHero_profession());
                i.putExtra("cover_photo", subsItem.getCover_photos());
                i.putExtra("fans_count", subsItem.getFans_count());*/
                startActivity(i);
            }
        });

        mTabLay = findViewById(R.id.tablayout);
        try {
            showHideProgressDialog(true);
            JSONObject loginJson = new JSONObject();
            loginJson.put("cat_id", "1");
            loginJson.put("hero_id", 1);
            getCategoryByHeroId(HostUrl.BaseUrl + "hero/getHero", loginJson);
            getTopicsByCategId(HostUrl.BaseUrl + "hero/getTopics", loginJson);

        } catch (Exception je) {

        }

    }


    private void setData() {
    }


    public void getCategoryByHeroId(String urlOne, JSONObject jsonObject) {

        // System.out.println("Auth key  " + auth_key);
        try {

            System.out.println(urlOne);

            System.out.println("json Category of  Heroes" + jsonObject);
            JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                    urlOne, jsonObject,
                    response -> {
                        System.out.println("Get Category By Id Response " + response);
                        showHideProgressDialog(false);

                        try {
                            JSONObject jb1 = response.getJSONObject("meta");
                            int code = jb1.getInt("code");
                            if (code == 200) {

                                JSONArray jsonObject1 = response.getJSONArray("Data");


                            }

                            // if (response.getString("Status").equalsIgnoreCase("true")) {
//                                    try {
//
                        } catch (JSONException je) {
                            je.printStackTrace();
                        }
                        try {

                        } catch (Exception e) {
                            e.printStackTrace();
                        }


                    }, error -> {
                showHideProgressDialog(false);
                System.out.println("12Error" + error.toString());
                try {
                    if (error instanceof NetworkError) {
                        // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                    } else if (error instanceof NoConnectionError) {
                        // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                    } else if (error.networkResponse.data != null) {
                        String body = new String(error.networkResponse.data, "UTF-8");
                        //////println("response from server ///" + body);


                        JSONObject obj = new JSONObject(body);
                        JSONObject meta = obj.getJSONObject("meta");
                        String messgae = meta.getString("message");


                        // Toast.makeText(CustomerListActivity.this, messgae, Toast.LENGTH_SHORT).show();
                        // DialogNScableApp.callDialog("Error", messgae, PaymentHistoryActivity.this);

                    } else {
                        //  DialogNScableApp.callDialog("Error", MessagesAccess.serverError, PaymentHistoryActivity.this);
                    }

                } catch (Exception e) {
                    Toast.makeText(AboutCelebrityActivity.this, "Server Error", Toast.LENGTH_SHORT).show();

                    //DialogNScableApp.callDialog("Error", MessagesAccess.serverError, PaymentHistoryActivity.this);
                    e.printStackTrace();
                }
            }) {

                @Override
                protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                    return super.parseNetworkResponse(response);
                }

                /**
                 * Passing some request headers
                 */
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    headers.put("Auth-Key", "");
                    return headers;
                }
            };

            // Wait 30 seconds and don't retry more than once
            jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(15000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            jsonObjReq.setShouldCache(true);
            RequestQueue queue = Volley.newRequestQueue(AboutCelebrityActivity.this);
            queue.add(jsonObjReq);

        } catch (Exception e) {

            e.printStackTrace();
        }


    }


    public void getTopicsByCategId(String urlOne, JSONObject jsonObject) {

        // System.out.println("Auth key  " + auth_key);
        try {

            System.out.println(urlOne);

            System.out.println("json Category of  Heroes" + jsonObject);
            JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                    urlOne, jsonObject,
                    response -> {
                        System.out.println("Get Category By Id Response " + response);
                        showHideProgressDialog(false);

                        try {
                            JSONObject jb1 = response.getJSONObject("meta");
                            int code = jb1.getInt("code");
                            if (code == 200) {

                                JSONArray jsonObject1 = response.getJSONArray("Data");
                                setupViewPager(jsonObject1);

                            }

                            // if (response.getString("Status").equalsIgnoreCase("true")) {
//                                    try {
//
                        } catch (JSONException je) {
                            je.printStackTrace();
                        }
                        try {

                           /* if (response.getJSONObject("meta").getBoolean("Status")) {
                                setupViewPager(response.getJSONArray("Data"));
                            }*/

                        } catch (Exception e) {
                            e.printStackTrace();
                        }


                    }, error -> {
                showHideProgressDialog(false);
                System.out.println("12Error" + error.toString());
                try {
                    if (error instanceof NetworkError) {
                        // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                    } else if (error instanceof NoConnectionError) {
                        // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                    } else if (error.networkResponse.data != null) {
                        String body = new String(error.networkResponse.data, "UTF-8");
                        //////println("response from server ///" + body);


                        JSONObject obj = new JSONObject(body);
                        JSONObject meta = obj.getJSONObject("meta");
                        String messgae = meta.getString("message");


                        // Toast.makeText(CustomerListActivity.this, messgae, Toast.LENGTH_SHORT).show();
                        // DialogNScableApp.callDialog("Error", messgae, PaymentHistoryActivity.this);

                    } else {
                        //  DialogNScableApp.callDialog("Error", MessagesAccess.serverError, PaymentHistoryActivity.this);
                    }

                } catch (Exception e) {
                    Toast.makeText(AboutCelebrityActivity.this, "Server Error", Toast.LENGTH_SHORT).show();

                    //DialogNScableApp.callDialog("Error", MessagesAccess.serverError, PaymentHistoryActivity.this);
                    e.printStackTrace();
                }
            }) {

                @Override
                protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                    return super.parseNetworkResponse(response);
                }

                /**
                 * Passing some request headers
                 */
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    headers.put("Auth-Key", "");
                    return headers;
                }
            };

            // Wait 30 seconds and don't retry more than once
            jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(15000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            jsonObjReq.setShouldCache(true);
            RequestQueue queue = Volley.newRequestQueue(AboutCelebrityActivity.this);
            queue.add(jsonObjReq);

        } catch (Exception e) {

            e.printStackTrace();
        }


    }


    private void setupViewPager(JSONArray jsonArray) throws JSONException {
        mViewPager = findViewById(R.id.viewPager);
        AboutCelebrityActivity.ViewPagerAdapter adapter = new AboutCelebrityActivity.ViewPagerAdapter(getSupportFragmentManager());


        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject categoryJsonObject = jsonArray.getJSONObject(i);
            String topic = categoryJsonObject.getJSONArray("topic").toString();
            adapter.addFrag(NewsFragment.newInstance(topic), categoryJsonObject.getString("category_name"));
        }

        mViewPager.setAdapter(adapter);
        mTabLay.setupWithViewPager(mViewPager);

    }


    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFrag(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(AboutCelebrityActivity.this, HomeActivity.class);
        startActivity(i);
    }


    /*  @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }*/


}
