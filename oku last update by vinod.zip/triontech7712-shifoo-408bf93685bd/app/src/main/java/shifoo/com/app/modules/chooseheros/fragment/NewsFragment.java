package shifoo.com.app.modules.chooseheros.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import oku.app.R;
import shifoo.com.app.modules.chooseheros.adapter.DataFragmentAdapter;
import shifoo.com.app.viewutils.SpacesItemDecoration;

/**
 * A simple {@link Fragment} subclass.
 */
public class NewsFragment extends Fragment {

    public static String TOPIC_KEY = "TOPIC_KEY";

    public NewsFragment() {
    }


    public static NewsFragment newInstance(String jsonArray) {
        NewsFragment newsFragment = new NewsFragment();
        Bundle bundle = new Bundle();
        bundle.putString(TOPIC_KEY, jsonArray);
        newsFragment.setArguments(bundle);
        return newsFragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.fragment_news, container, false);
        RecyclerView recyclerView = (RecyclerView) rootview.findViewById(R.id.simpleGridView);


        StaggeredGridLayoutManager staggeredGridLayoutManager =
                new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL);

        recyclerView.setLayoutManager(staggeredGridLayoutManager);

        Bundle args = getArguments();

        String jsonArrayString = args.getString(TOPIC_KEY);

        try {
            JSONArray jsonArray = new JSONArray(jsonArrayString);
            recyclerView.setAdapter(new DataFragmentAdapter(jsonArray));
            SpacesItemDecoration decoration = new SpacesItemDecoration(12);
            recyclerView.addItemDecoration(decoration);
        } catch (Exception e) {
            e.printStackTrace();
        }


        // RecyclerView.ItemDecoration.class

        // Inflate the layout for this fragment
        return rootview;
    }

}

