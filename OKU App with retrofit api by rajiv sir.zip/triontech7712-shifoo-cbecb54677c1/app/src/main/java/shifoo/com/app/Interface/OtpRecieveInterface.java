package shifoo.com.app.Interface;

public interface OtpRecieveInterface {

    void onOtpRecieved(String otp);

}
