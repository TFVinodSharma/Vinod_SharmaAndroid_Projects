package shifoo.com.shifoo.modules.login.view;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import shifoo.com.shifoo.R;
import shifoo.com.shifoo.modules.chooseheros.view.ChooseHerosActivity;

public class AvtarActivity extends AppCompatActivity {

    TextView TxtHi,TxtUser;





     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avtar);

        TxtHi = (TextView) findViewById(R.id.txthi);
        TxtUser = (TextView) findViewById(R.id.txt_avtarheading);
        final Button SelectAvtar=findViewById(R.id.selectavtar);



        final LinearLayout Avtar1=findViewById(R.id.avtar1);
       final   LinearLayout Avtar2=findViewById(R.id.avtar2);
      final  LinearLayout Avtar3=findViewById(R.id.avtar3);
       final LinearLayout Avtar4=findViewById(R.id.avtar4);
       final LinearLayout Avtar5=findViewById(R.id.avtar5);
       final LinearLayout Avtar6=findViewById(R.id.avtar6);


        Typeface Txthi = Typeface.createFromAsset(getAssets(),
                "fonts/JosefinSans_Bold.ttf");
        TxtHi.setTypeface(Txthi);
        TxtUser.setTypeface(Txthi);




        SelectAvtar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(AvtarActivity.this,ChooseHerosActivity.class);
                startActivity(i);
            }
        });




        Avtar1.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                if (v.equals(Avtar1))
                {
                   // Toast.makeText(AvtarActivity.this, " Selected", Toast.LENGTH_SHORT).show();
                    Avtar1.setBackground(getDrawable(R.drawable.outer_back_layout));
                    SelectAvtar.setBackground(getDrawable(R.drawable.round));



                }
                else
                {
                    Toast.makeText(AvtarActivity.this, "not selected", Toast.LENGTH_SHORT).show();
                }
            }
        });


        Avtar2.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                if (v.equals(Avtar2))
                {
                    // Toast.makeText(AvtarActivity.this, " Selected", Toast.LENGTH_SHORT).show();
                    Avtar2.setBackground(getDrawable(R.drawable.outer_back_layout));
                    SelectAvtar.setBackground(getDrawable(R.drawable.round));



                }
                else
                {
                    Toast.makeText(AvtarActivity.this, "not selected", Toast.LENGTH_SHORT).show();
                }
            }
        });
        Avtar3.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                if (v.equals(Avtar3))
                {
                    // Toast.makeText(AvtarActivity.this, " Selected", Toast.LENGTH_SHORT).show();
                    Avtar3.setBackground(getDrawable(R.drawable.outer_back_layout));
                    SelectAvtar.setBackground(getDrawable(R.drawable.round));



                }
                else
                {
                    Toast.makeText(AvtarActivity.this, "not selected", Toast.LENGTH_SHORT).show();
                }
            }
        });
        Avtar4.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                if (v.equals(Avtar4))
                {
                    // Toast.makeText(AvtarActivity.this, " Selected", Toast.LENGTH_SHORT).show();
                    Avtar4.setBackground(getDrawable(R.drawable.outer_back_layout));
                    SelectAvtar.setBackground(getDrawable(R.drawable.round));



                }
                else
                {
                    Toast.makeText(AvtarActivity.this, "not selected", Toast.LENGTH_SHORT).show();
                }
            }
        });
        Avtar5.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                if (v.equals(Avtar5))
                {
                    // Toast.makeText(AvtarActivity.this, " Selected", Toast.LENGTH_SHORT).show();
                    Avtar5.setBackground(getDrawable(R.drawable.outer_back_layout));
                    SelectAvtar.setBackground(getDrawable(R.drawable.round));



                }
                else
                {
                    Toast.makeText(AvtarActivity.this, "not selected", Toast.LENGTH_SHORT).show();
                }
            }
        });
        Avtar6.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                if (v.equals(Avtar6))
                {
                    // Toast.makeText(AvtarActivity.this, " Selected", Toast.LENGTH_SHORT).show();
                    Avtar6.setBackground(getDrawable(R.drawable.outer_back_layout));
                    SelectAvtar.setBackground(getDrawable(R.drawable.round));



                }
                else
                {
                    Toast.makeText(AvtarActivity.this, "not selected", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }

    }

