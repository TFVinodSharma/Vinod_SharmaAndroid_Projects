package shifoo.com.app.Models;

public class CelebrityMoreInfoModel {


    private String hero_id = "";
    private String section_title = "";
    private String hero_profile_section_id = "";
    private String section_sort_order = "";
    private String section_type = "";
    private String section_description = "";

    private  String row_name="";
    private String row_value="";
    private String section_table_row_id="";

    public String getHero_id() {
        return hero_id;
    }

    public void setHero_id(String hero_id) {
        this.hero_id = hero_id;
    }

    public String getSection_title() {
        return section_title;
    }

    public void setSection_title(String section_title) {
        this.section_title = section_title;
    }

    public String getHero_profile_section_id() {
        return hero_profile_section_id;
    }

    public void setHero_profile_section_id(String hero_profile_section_id) {
        this.hero_profile_section_id = hero_profile_section_id;
    }

    public String getSection_sort_order() {
        return section_sort_order;
    }

    public void setSection_sort_order(String section_sort_order) {
        this.section_sort_order = section_sort_order;
    }

    public String getSection_type() {
        return section_type;
    }

    public void setSection_type(String section_type) {
        this.section_type = section_type;
    }

    public String getSection_description() {
        return section_description;
    }

    public void setSection_description(String section_description) {
        this.section_description = section_description;
    }

    public String getRow_name() {
        return row_name;
    }

    public void setRow_name(String row_name) {
        this.row_name = row_name;
    }

    public String getRow_value() {
        return row_value;
    }

    public void setRow_value(String row_value) {
        this.row_value = row_value;
    }

    public String getSection_table_row_id() {
        return section_table_row_id;
    }

    public void setSection_table_row_id(String section_table_row_id) {
        this.section_table_row_id = section_table_row_id;
    }
}
