android-flickr-recent
=====================

Simple android app for getting recent images from flickr using RoboSpice and Retrofit for cache and network.
