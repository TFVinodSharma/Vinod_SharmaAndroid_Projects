package shifoo.com.shifoo.modules.chooseheros.view;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import shifoo.com.shifoo.R;
import shifoo.com.shifoo.modules.chooseheros.adapter.AboutCelebrityAdapter;
import shifoo.com.shifoo.modules.home.view.HomeActivity;

public class AboutCelebrityActivity extends AppCompatActivity {

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        onBackPressed();
        Intent i=new Intent(this,HomeActivity.class);
        startActivity(i);
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_celebrity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        LinearLayout Btn_MoreInfo=(LinearLayout) findViewById(R.id.btn_moreinfo);
        Btn_MoreInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(AboutCelebrityActivity.this,CelebrityMoreInfoActivity.class);
                startActivity(i);
            }
        });

        TabLayout tab=findViewById(R.id.tablayout);
        tab.addTab(tab.newTab().setText("Popular"));
        tab.addTab(tab.newTab().setText("MS DHONI"));
        tab.addTab(tab.newTab().setText("Learn Cricket"));
        tab.addTab(tab.newTab().setText("All"));

        ViewPager viewPager=findViewById(R.id.viewPager);


        AboutCelebrityAdapter adapter = new AboutCelebrityAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tab));

        tab.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


    }
}
