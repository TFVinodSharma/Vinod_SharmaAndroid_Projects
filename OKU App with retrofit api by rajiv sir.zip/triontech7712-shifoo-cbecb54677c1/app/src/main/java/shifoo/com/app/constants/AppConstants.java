package shifoo.com.app.constants;

public interface AppConstants {

    String BASE_URL = "http://staging.okuapp.com";

}
