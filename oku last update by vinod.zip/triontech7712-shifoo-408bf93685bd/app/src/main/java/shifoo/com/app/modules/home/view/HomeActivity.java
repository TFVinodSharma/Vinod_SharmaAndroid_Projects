package shifoo.com.app.modules.home.view;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

import oku.app.R;
import shifoo.com.app.Models.GetHeroesModel;
import shifoo.com.app.apppreferences.AppPreferences;
import shifoo.com.app.base.activity.BaseActivity;
import shifoo.com.app.library.HostUrl;
import shifoo.com.app.modules.home.adapter.GetHeroesAdapter;
import shifoo.com.app.modules.login.view.LoginActivity;
import shifoo.com.app.modules.profile.view.ProfileActivity;

public class HomeActivity extends BaseActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    Toolbar Toolbar;
   /* int logos[] = {R.mipmap.dhoni, R.mipmap.dhoni, R.mipmap.dhoni, R.mipmap.dhoni,
            R.mipmap.dhoni, R.mipmap.dhoni};
*/
    private ArrayList<GetHeroesModel> mGetHeroesList;
    private GetHeroesAdapter getHerosAdapter;
    private RecyclerView ChooseHerosRecycler;
    String username, user_id;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(Toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        username = mAppPrefrences.getString(AppPreferences.SharedPreferncesKeys.user_name.toString(), "");
        user_id = mAppPrefrences.getString(AppPreferences.SharedPreferncesKeys.user_id.toString(), "");


//  find views id's here
       // TextView Txt_Celebrity_About = findViewById(R.id.txt_celebrity_about);
        TextView Txt_Continue_Reading = findViewById(R.id.txt_continue_reading);
        TextView Txt_Welcome = findViewById(R.id.txt_welcome);
        CircleImageView AvtarProfile = findViewById(R.id.avtarprofile);


        ChooseHerosRecycler = findViewById(R.id.choose_herosrecycler);

        LinearLayoutManager layoutManager
                = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        ChooseHerosRecycler.setLayoutManager(layoutManager);



        AvtarProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(i);
            }
        });


//  Typeface here
        Typeface HerosTypeFace = Typeface.createFromAsset(getAssets(),
                "fonts/JosefinSans_Bold.ttf");
       // Txt_Celebrity_About.setTypeface(HerosTypeFace);
        Txt_Continue_Reading.setTypeface(HerosTypeFace);
        Txt_Welcome.setTypeface(HerosTypeFace);


        //PHome.setProgressTintList(ColorStateList.valueOf(Color.YELLOW));


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, Toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.mipmap.navigation_icon);


        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);

        navigationView.getHeaderView(0).findViewById(R.id.viewprofile).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, ProfileActivity.class));
            }
        });
        navigationView.setBackgroundColor(getResources().getColor(R.color.white));
        navigationView.setItemIconTintList(null);


        try {
            showHideProgressDialog(true);
            JSONObject loginJson = new JSONObject();
            // loginJson.put("PhoneNumber", mPhoneNumber);
            getAllHeroes(HostUrl.BaseUrl + "hero/getHeros", loginJson);
        } catch (Exception je) {

        }


        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    public void getAllHeroes(String urlOne, JSONObject jsonObject) {

        // System.out.println("Auth key  " + auth_key);
        try {

            System.out.println(urlOne);

            System.out.println("json All Heroes" + jsonObject);
            JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                    urlOne, jsonObject,
                    new Response.Listener<JSONObject>() {

                        @Override
                        public void onResponse(JSONObject response) {
                            System.out.println("Get All Heroes Response " + response);
                            showHideProgressDialog(false);
                            try {


                                if (response.optJSONObject("meta").getInt("code") == 200) {
                                    try {

                                        JSONArray dataArray = response.getJSONArray("Data");

                                        setHeroesData(dataArray);


                                    } catch (JSONException je) {
                                        je.printStackTrace();
                                    }


                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                        }
                    }, new Response.ErrorListener() {


                @Override
                public void onErrorResponse(VolleyError error) {
                    showHideProgressDialog(false);
                    System.out.println("12Error" + error.toString());
                    try {
                        if (error instanceof NetworkError) {
                            // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                        } else if (error instanceof NoConnectionError) {
                            // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                        } else if (error.networkResponse.data != null) {
                            String body = new String(error.networkResponse.data, "UTF-8");
                            //////println("response from server ///" + body);


                            JSONObject obj = new JSONObject(body);
                            // JSONObject meta = obj.getJSONObject("meta");
                            //  String messgae = meta.getString("message");


                            // Toast.makeText(CustomerListActivity.this, messgae, Toast.LENGTH_SHORT).show();
                            // DialogNScableApp.callDialog("Error", messgae, PaymentHistoryActivity.this);

                        } else {
                            //  DialogNScableApp.callDialog("Error", MessagesAccess.serverError, PaymentHistoryActivity.this);
                        }

                    } catch (Exception e) {
                        Toast.makeText(HomeActivity.this, "Server Error", Toast.LENGTH_SHORT).show();

                        //DialogNScableApp.callDialog("Error", MessagesAccess.serverError, PaymentHistoryActivity.this);
                        e.printStackTrace();
                    }
                }
            }) {

                @Override
                protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                    return super.parseNetworkResponse(response);
                }

                /**
                 * Passing some request headers
                 */
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    headers.put("Auth-Key", "");
                    return headers;
                }
            };

            // Wait 30 seconds and don't retry more than once
            jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(15000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            jsonObjReq.setShouldCache(true);
            RequestQueue queue = Volley.newRequestQueue(HomeActivity.this);
            queue.add(jsonObjReq);

        } catch (Exception e) {

            e.printStackTrace();
        }


    }

    public void LogoutUser(String urlOne, JSONObject jsonObject) {

        // System.out.println("Auth key  " + auth_key);
        try {

            System.out.println(urlOne);

            System.out.println("json All Heroes" + jsonObject);
            JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                    urlOne, jsonObject,
                    new Response.Listener<JSONObject>() {

                        @Override
                        public void onResponse(JSONObject response) {
                            System.out.println("Logout Response " + response);
                            showHideProgressDialog(false);
                            try {

                                if (response.optJSONObject("meta").getInt("code") == 200) {
                                    try {

                                        Toast.makeText(HomeActivity.this, "Logout Successfully", Toast.LENGTH_SHORT).show();
                                        mAppPrefrences.clearPreferences();
                                        Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                                        startActivity(intent);


                                    } catch (Exception je) {
                                        je.printStackTrace();
                                    }


                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                        }
                    }, new Response.ErrorListener() {


                @Override
                public void onErrorResponse(VolleyError error) {
                    showHideProgressDialog(false);
                    System.out.println("12Error" + error.toString());
                    try {
                        if (error instanceof NetworkError) {
                            // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                        } else if (error instanceof NoConnectionError) {
                            // DialogNScableApp.callDialog("Error", MessagesAccess.noInternetConnection, PaymentHistoryActivity.this);
                        } else if (error.networkResponse.data != null) {
                            String body = new String(error.networkResponse.data, "UTF-8");
                            //////println("response from server ///" + body);


                            JSONObject obj = new JSONObject(body);
                            // JSONObject meta = obj.getJSONObject("meta");
                            //  String messgae = meta.getString("message");


                            // Toast.makeText(CustomerListActivity.this, messgae, Toast.LENGTH_SHORT).show();
                            // DialogNScableApp.callDialog("Error", messgae, PaymentHistoryActivity.this);

                        } else {
                            //  DialogNScableApp.callDialog("Error", MessagesAccess.serverError, PaymentHistoryActivity.this);
                        }

                    } catch (Exception e) {
                        Toast.makeText(HomeActivity.this, "Server Error", Toast.LENGTH_SHORT).show();

                        //DialogNScableApp.callDialog("Error", MessagesAccess.serverError, PaymentHistoryActivity.this);
                        e.printStackTrace();
                    }
                }
            }) {

                @Override
                protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                    return super.parseNetworkResponse(response);
                }

                /**
                 * Passing some request headers
                 */
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    headers.put("Auth-Key", "");
                    return headers;
                }
            };

            // Wait 30 seconds and don't retry more than once
            jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(15000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            jsonObjReq.setShouldCache(true);
            RequestQueue queue = Volley.newRequestQueue(HomeActivity.this);
            queue.add(jsonObjReq);

        } catch (Exception e) {

            e.printStackTrace();
        }


    }


    private void setHeroesData(JSONArray heroarray) {

        try {
            for (int i = 0; i < heroarray.length(); i++) {
                JSONObject jsonObject = heroarray.getJSONObject(i);
                GetHeroesModel details = new GetHeroesModel();


                mGetHeroesList = new ArrayList<>();

                details.setHero_id(jsonObject.getString("hero_id"));
                details.setHero_name(jsonObject.getString("hero_name"));
                details.setHero_profession(jsonObject.getString("hero_profession"));
                details.setHero_short_description(jsonObject.getString("hero_short_description"));
                details.setFans_count(jsonObject.getString("fans_count"));
                details.setCover_photos(jsonObject.getString("hero_coverphoto"));
                details.setSort_order(jsonObject.getString("sort_order"));
                details.setHero_thumbnail(jsonObject.getString("hero_thumbnail"));
                details.setSetSelected(0);
                mGetHeroesList.add(details);

            }


        } catch (JSONException je) {
            je.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (mGetHeroesList != null) {
            getHerosAdapter = new GetHeroesAdapter(HomeActivity.this, mGetHeroesList, HomeActivity.this);
            ChooseHerosRecycler.setAdapter(getHerosAdapter);
        }

    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_logout) {


            try {
                showHideProgressDialog(true);
                JSONObject loginJson = new JSONObject();
                loginJson.put("user_id", user_id);
                LogoutUser(HostUrl.BaseUrl + "hero/getHeros", loginJson);
            } catch (Exception je) {

            }


            // Handle the camera action
        } else if (id == R.id.nav_home) {

        } else if (id == R.id.nav_notification) {
            Toast.makeText(this, "Under Development", Toast.LENGTH_SHORT).show();

        } else if (id == R.id.nav_invite) {

        } else if (id == R.id.nav_aboutus) {
            Toast.makeText(getApplicationContext(), "clicked", Toast.LENGTH_SHORT).show();
//            Intent i = new Intent(HomeActivity.this, AboutUsActivity.class);
//            startActivity(i);


            String AboutUS = "https://leverageedu.com/about-us";

            //////////System.out.println(TNC);


            try {
                try {
                    Uri uri = Uri.parse("googlechrome://navigate?url=" + AboutUS);
                    Intent i1 = new Intent(Intent.ACTION_VIEW, uri);
                    i1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i1);
                } catch (ActivityNotFoundException e) {
                    Uri uri = Uri.parse(AboutUS);
                    // Chrome is probably not installed
                    // OR not selected as default browser OR if no Browser is selected as default browser
                    Intent i1 = new Intent(Intent.ACTION_VIEW, uri);
                    i1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i1);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }


        } else if (id == R.id.nav_policy) {

            String PrivacyPolicy = "https://leverageedu.com/privacy-policy";

            try {
                try {
                    Uri uri = Uri.parse("googlechrome://navigate?url=" + PrivacyPolicy);
                    Intent i1 = new Intent(Intent.ACTION_VIEW, uri);
                    i1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i1);
                } catch (ActivityNotFoundException e) {
                    Uri uri = Uri.parse(PrivacyPolicy);
                    // Chrome is probably not installed
                    // OR not selected as default browser OR if no Browser is selected as default browser
                    Intent i1 = new Intent(Intent.ACTION_VIEW, uri);
                    i1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i1);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }


        } else if (id == R.id.nav_termandcondition) {
            String TermsConditions = "https://leverageedu.com/terms-and-conditions";

            try {
                try {
                    Uri uri = Uri.parse("googlechrome://navigate?url=" + TermsConditions);
                    Intent i1 = new Intent(Intent.ACTION_VIEW, uri);
                    i1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i1);
                } catch (ActivityNotFoundException e) {
                    Uri uri = Uri.parse(TermsConditions);
                    // Chrome is probably not installed
                    // OR not selected as default browser OR if no Browser is selected as default browser
                    Intent i1 = new Intent(Intent.ACTION_VIEW, uri);
                    i1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i1);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }


        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


}
