package shifoo.com.app.modules.login.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import oku.app.R;


public class TermsofuseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_termsofuse);
    }
}
