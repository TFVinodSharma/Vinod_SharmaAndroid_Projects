package shifoo.com.shifoo.modules.login.view;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import android.widget.TextView;
import android.widget.Toast;
import com.bachors.prefixinput.EditText;

import shifoo.com.shifoo.R;
import shifoo.com.shifoo.modules.chooseheros.view.ChooseHerosActivity;

public class LoginActivity extends AppCompatActivity
        {
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


// view's id find here
         TextView textView_header = (TextView) findViewById(R.id.tv_header);
        TextView   textView_header1 = (TextView) findViewById(R.id.tv_header1);
        TextView textView_header2  = (TextView) findViewById(R.id.tv_header2);
        final CheckBox ck = (CheckBox) findViewById(R.id.checkbox);
         TextView privacy = (TextView) findViewById(R.id.tv_header3);
          final  Button accepttermandcondition = findViewById(R.id.accepttermandcondition);
         final   com.bachors.prefixinput.EditText phoneNumber = findViewById(R.id.edit_no);
        phoneNumber.setPrefix("+91");
        phoneNumber.setSelection(3);

        // fonts use here
        Typeface face = Typeface.createFromAsset(getAssets(),
                "fonts/JosefinSans_Bold.ttf");
        textView_header.setTypeface(face);
        textView_header1.setTypeface(face);
        textView_header2.setTypeface(face);
        ck.setTypeface(face);
        privacy.setTypeface(face);
        accepttermandcondition.setTypeface(face);



        phoneNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 13 && ck.isChecked()) {
                    accepttermandcondition.setBackground(getDrawable(R.drawable.round));
                    accepttermandcondition.setEnabled(true);
                } else {
                    accepttermandcondition.setBackground(getDrawable(R.drawable.roundgrey));
                    accepttermandcondition.setEnabled(false);
                }
            }
        });

        ck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked && phoneNumber.getText().toString().length() == 13) {
                    accepttermandcondition.setBackground(getDrawable(R.drawable.round));
                    accepttermandcondition.setEnabled(true);
                    accepttermandcondition.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent i = new Intent(LoginActivity.this, OtpActivity.class);
                            startActivity(i);

                        }
                    });
                } else {
                    accepttermandcondition.setBackground(getDrawable(R.drawable.roundgrey));
                    accepttermandcondition.setEnabled(false);

                }
            }
        });




    }


}
