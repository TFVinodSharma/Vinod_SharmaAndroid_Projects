package shifoo.com.shifoo.modules.chooseheros.view;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toolbar;

import org.w3c.dom.Text;

import shifoo.com.shifoo.R;
import shifoo.com.shifoo.modules.home.view.HomeActivity;

public class CelebrityMoreInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_celebrity_more_info);

        android.support.v7.widget.Toolbar Tool = (android.support.v7.widget.Toolbar) findViewById(R.id.tool);
        setSupportActionBar(Tool);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);



        TextView User_Profile_name=findViewById(R.id.user_profile_name);
        TextView User_Profile_Short_Bio=findViewById(R.id.user_profile_short_bio);
        TextView Txt_Fans=findViewById(R.id.txt_fans);
        TextView Txt_words=findViewById(R.id.txt_words);
        TextView Bio=findViewById(R.id.bio);
        TextView Record=findViewById(R.id.record);
        final TextView Info=findViewById(R.id.info);
        TextView Captaincy=findViewById(R.id.captaincy);
        TextView Awards=findViewById(R.id.awards);
        TextView Career=findViewById(R.id.carrer);
        TextView SecondCareer=findViewById(R.id.secondcareer);


        // fonts use here
        Typeface Celebrity = Typeface.createFromAsset(getAssets(),
                "fonts/JosefinSans_Bold.ttf");
        User_Profile_name.setTypeface(Celebrity);
        User_Profile_Short_Bio.setTypeface(Celebrity);
        Txt_Fans.setTypeface(Celebrity);
        Txt_words.setTypeface(Celebrity);
        Bio.setTypeface(Celebrity);
        Record.setTypeface(Celebrity);
        Info.setTypeface(Celebrity);
        Captaincy.setTypeface(Celebrity);
        Awards.setTypeface(Celebrity);
        Career.setTypeface(Celebrity);
        SecondCareer.setTypeface(Celebrity);


        Bio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Info.setVisibility(View.VISIBLE);
            }
        });

    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

}
