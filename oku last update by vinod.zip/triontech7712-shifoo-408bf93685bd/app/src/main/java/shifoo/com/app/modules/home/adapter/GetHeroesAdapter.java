package shifoo.com.app.modules.home.adapter;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import oku.app.R;
import shifoo.com.app.Interface.HeroSelectionInterface;
import shifoo.com.app.Models.GetHeroesModel;
import shifoo.com.app.modules.chooseheros.adapter.ChooseHerosAdapter;
import shifoo.com.app.modules.home.adapter.GetHeroesAdapter.GetHeroesHolder;
import shifoo.com.app.modules.home.view.HomeActivity;


public class GetHeroesAdapter extends RecyclerView.Adapter<GetHeroesHolder> {


    private Context mContext;

    private List<GetHeroesModel> heroesList;

    ImageLoader imageLoader = ImageLoader.getInstance();
    private ImageLoadingListener imageListener;
    DisplayImageOptions options;


    public GetHeroesAdapter(Context context, List<GetHeroesModel> list, HomeActivity homeActivity) {

        this.mContext = context;
        this.heroesList = list;



        options = new DisplayImageOptions.Builder()
                .cacheInMemory()
                .cacheOnDisc().build();

        imageListener = new ImageDisplayListener();
        imageLoader = ImageLoader.getInstance();
        imageLoader.init(ImageLoaderConfiguration.createDefault(mContext));

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public GetHeroesHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.get_heroes_list_item, null);
        GetHeroesHolder subs_holder = new GetHeroesHolder(v);


        return subs_holder;
    }

    @Override
    public void onBindViewHolder(GetHeroesHolder holder, int position) {

        final GetHeroesModel subsItem = heroesList.get(position);

        holder.TxtNameCelebrity.setText(subsItem.getHero_name());
        holder.TxtDesignation.setText(subsItem.getHero_profession());

        ImageAware imageAware = new ImageViewAware(holder.imageView, false);
        imageLoader.displayImage(subsItem.getCover_photos(), imageAware, options);

        }

    @Override
    public int getItemCount() {
        return heroesList.size();
    }

    private static class ImageDisplayListener extends
            SimpleImageLoadingListener {

        static final List<String> displayedImages = Collections
                .synchronizedList(new LinkedList<String>());

        @Override
        public void onLoadingComplete(String imageUri, View view,
                                      Bitmap loadedImage) {
            if (loadedImage != null) {
                ImageView imageView = (ImageView) view;
                boolean firstDisplay = !displayedImages.contains(imageUri);
                if (firstDisplay) {
                    FadeInBitmapDisplayer.animate(imageView, 500);
                    displayedImages.add(imageUri);
                }
            }
        }
    }

    public class GetHeroesHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

            //ImageView imageView;
        TextView TxtNameCelebrity, TxtDesignation;
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        public GetHeroesHolder(@NonNull View itemView) {
            super(itemView);
            mContext = itemView.getContext();

            imageView = itemView.findViewById(R.id.imagec);
            ProgressBar PHome = itemView.findViewById(R.id.pBar);
            PHome.setProgressTintList(ColorStateList.valueOf(Color.YELLOW));

            TxtNameCelebrity = itemView.findViewById(R.id.txt_celebrity_name);
            TxtDesignation = itemView.findViewById(R.id.designaion_celi);


            Typeface adapterHerosTypeFace = Typeface.createFromAsset(itemView.getContext().getAssets(), "fonts/JosefinSans_Bold.ttf");
            this.TxtNameCelebrity.setTypeface(adapterHerosTypeFace);
            this.TxtDesignation.setTypeface(adapterHerosTypeFace);


        }
    }
}

