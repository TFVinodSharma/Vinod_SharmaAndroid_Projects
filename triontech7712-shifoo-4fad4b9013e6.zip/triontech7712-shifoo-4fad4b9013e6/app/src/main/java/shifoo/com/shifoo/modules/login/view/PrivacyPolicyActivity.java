package shifoo.com.shifoo.modules.login.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import shifoo.com.shifoo.R;

public class PrivacyPolicyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_policy);
    }
}
