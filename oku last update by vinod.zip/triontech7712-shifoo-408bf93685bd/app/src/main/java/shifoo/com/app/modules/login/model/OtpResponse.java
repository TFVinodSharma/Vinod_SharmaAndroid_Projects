package shifoo.com.app.modules.login.model;

import java.io.Serializable;

import shifoo.com.app.base.response.BaseResponse;

public class OtpResponse extends BaseResponse implements Serializable {
}
