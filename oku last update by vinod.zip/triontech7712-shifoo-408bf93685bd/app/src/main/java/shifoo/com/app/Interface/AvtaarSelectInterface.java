package shifoo.com.app.Interface;

public interface AvtaarSelectInterface {


    void onSelectAvtaar(int index);
}
