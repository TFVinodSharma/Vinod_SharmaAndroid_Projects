package shifoo.com.app.modules.login.model;

import java.io.Serializable;

import shifoo.com.app.base.response.BaseResponse;

public class SignUpResponse extends BaseResponse implements Serializable {
}
