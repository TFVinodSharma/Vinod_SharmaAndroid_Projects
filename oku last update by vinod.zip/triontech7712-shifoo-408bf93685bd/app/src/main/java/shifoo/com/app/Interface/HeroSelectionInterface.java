package shifoo.com.app.Interface;

public interface HeroSelectionInterface {

    void onItemClick(int flag, int pos);
}
