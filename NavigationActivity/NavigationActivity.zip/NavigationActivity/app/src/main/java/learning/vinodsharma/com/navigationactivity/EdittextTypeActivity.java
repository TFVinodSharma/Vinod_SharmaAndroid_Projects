package learning.vinodsharma.com.navigationactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class EdittextTypeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edittext_type);
    }
}
