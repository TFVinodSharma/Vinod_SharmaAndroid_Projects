package shifoo.com.app.modules.chooseheros.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import oku.app.R;
import shifoo.com.app.Interface.HeroSelectionInterface;
import shifoo.com.app.Models.chooseHeroesModel;
import shifoo.com.app.modules.chooseheros.adapter.ChooseHerosAdapter.ChooseHeroesHolder;

public class ChooseHerosAdapter extends RecyclerView.Adapter<ChooseHeroesHolder> {

    private Context mContext;

    private List<chooseHeroesModel> heroesList;

    ImageLoader imageLoader = ImageLoader.getInstance();
    ImageLoadingListener imageListener;
    DisplayImageOptions options;


    private HeroSelectionInterface heroSelectionInterface;

    public ChooseHerosAdapter(Context context, List<chooseHeroesModel> list, HeroSelectionInterface listener) {

        this.mContext = context;
        this.heroesList = list;
        this.heroSelectionInterface = listener;


        options = new DisplayImageOptions.Builder()
                //  .showImageOnFail(R.mipmap.product_square)
                // .showStubImage(R.mipmap.product_square)
                // .showImageForEmptyUri(R.mipmap.product_square)
                .cacheInMemory(true)
                .cacheOnDisc(true)
                .resetViewBeforeLoading(true)
                .build();
        imageLoader = ImageLoader.getInstance();
        imageListener = new ImageDisplayListener();
        imageLoader.init(ImageLoaderConfiguration.createDefault(mContext));
    }

    @Override
    public ChooseHeroesHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_chooseheros, null);
        ChooseHeroesHolder subs_holder = new ChooseHeroesHolder(v);


        return subs_holder;
    }

    @Override
    public void onBindViewHolder(ChooseHeroesHolder holder, int position) {

        final chooseHeroesModel subsItem = heroesList.get(position);

        holder.Name.setText(subsItem.getHero_name());
        holder.Designation.setText(subsItem.getHero_profession());

        ImageAware imageAware = new ImageViewAware(holder.imageView, false);
        imageLoader.getInstance().displayImage(subsItem.getCover_photos(), imageAware, options);

        if (subsItem.getSetSelected() == 0) {
            holder.mCheckedHeros.setVisibility(View.INVISIBLE);
        } else {
            holder.mCheckedHeros.setVisibility(View.VISIBLE);
        }


        holder.top_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                for (int i = 0; i < heroesList.size(); i++) {
                    final chooseHeroesModel subsItem = heroesList.get(i);
                    if (i == position) {
                        subsItem.setSetSelected(1);
                    } else {
                        subsItem.setSetSelected(0);
                    }

                }

                holder.mCheckedHeros.setVisibility(View.VISIBLE);
                heroSelectionInterface.onItemClick(1, position);
                notifyDataSetChanged();
            }
        });


    }

    @Override
    public int getItemCount() {
        return heroesList.size();
    }

    private static class ImageDisplayListener extends
            SimpleImageLoadingListener {

        static final List<String> displayedImages = Collections
                .synchronizedList(new LinkedList<String>());

        @Override
        public void onLoadingComplete(String imageUri, View view,
                                      Bitmap loadedImage) {
            if (loadedImage != null) {
                ImageView imageView = (ImageView) view;
                boolean firstDisplay = !displayedImages.contains(imageUri);
                if (firstDisplay) {
                    FadeInBitmapDisplayer.animate(imageView, 500);
                    displayedImages.add(imageUri);
                }
            }
        }
    }

    public class ChooseHeroesHolder extends RecyclerView.ViewHolder {
        TextView Name, Designation;
        Context context;
        ImageView imageView, mCheckedHeros;
        LinearLayout top_ll;

        public ChooseHeroesHolder(@NonNull View itemView) {
            super(itemView);
            context = itemView.getContext();

            Name = itemView.findViewById(R.id.txt_name);
            Designation = itemView.findViewById(R.id.txt_designation);
            imageView = itemView.findViewById(R.id.image);
            mCheckedHeros = itemView.findViewById(R.id.checkedheros);
            top_ll = itemView.findViewById(R.id.top_ll);
            Typeface adapterTypeFace = Typeface.createFromAsset(itemView.getContext().getAssets(), "fonts/JosefinSans_Bold.ttf");
            this.Name.setTypeface(adapterTypeFace);
            this.Designation.setTypeface(adapterTypeFace);

        }
    }
}

