package bingo.binaryfork.com.bingo.flickr.model;

import java.util.ArrayList;

public class PhotosResponse {

    public Photos photos;

    public class Photos {
        public ArrayList<Photo> photo;
    }
}