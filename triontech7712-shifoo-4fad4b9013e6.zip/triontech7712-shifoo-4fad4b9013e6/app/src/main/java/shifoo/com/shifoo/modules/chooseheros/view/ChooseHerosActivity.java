package shifoo.com.shifoo.modules.chooseheros.view;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import shifoo.com.shifoo.R;
import shifoo.com.shifoo.modules.chooseheros.adapter.ChooseHerosAdapter;

public class ChooseHerosActivity extends AppCompatActivity {

    public  String[] Name={"Ms Dhoni","Ms Dhoni","Ms Dhoni"};
    public  String[] Rank={"Crickter ","Crickter","Crickter"};

TextView Txt_heros,UserName,ChooseDreamHero,UnlockedHeros,Txt_Name,Txt_Designation;
Button GetStarted;
    RecyclerView ChooseHeros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_heros);


// find view's id
        ChooseHeros=findViewById(R.id.choose_heros);
        Txt_heros=findViewById(R.id.txt_heros);
        UserName=findViewById(R.id.username);
        UnlockedHeros=findViewById(R.id.txt_unlockedheros);
        ChooseDreamHero=findViewById(R.id.txt_dreamhero);
        GetStarted=findViewById(R.id.btn_started);




        // Set adapter on Recyclerview
        ChooseHeros.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        ChooseHeros.setAdapter(new ChooseHerosAdapter(Name,Rank));


        // typeface fonts
        Typeface HerosTypeFace = Typeface.createFromAsset(getAssets(),
                "fonts/JosefinSans_Bold.ttf");
        Txt_heros.setTypeface(HerosTypeFace);
        UserName.setTypeface(HerosTypeFace);
        UnlockedHeros.setTypeface(HerosTypeFace);
        ChooseDreamHero.setTypeface(HerosTypeFace);




    }
}
