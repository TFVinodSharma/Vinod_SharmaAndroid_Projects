package thuy.flickr

data class PhotoSize(
    val width: Int,
    val height: Int,
    val link: String
)
