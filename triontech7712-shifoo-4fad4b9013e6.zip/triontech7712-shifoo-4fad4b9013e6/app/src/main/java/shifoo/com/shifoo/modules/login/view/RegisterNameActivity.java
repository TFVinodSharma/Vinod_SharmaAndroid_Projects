package shifoo.com.shifoo.modules.login.view;

import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import shifoo.com.shifoo.R;

public class RegisterNameActivity extends AppCompatActivity {
    TextView TVh,TVn;
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_name);

        final Button WelcomeProceed=(Button)findViewById(R.id.welcomeproceed);
        EditText PersonNmae=findViewById(R.id.personname);
        TVh = (TextView) findViewById(R.id.nameheading);
        TVn = (TextView) findViewById(R.id.nameText);

        EditText PersonName=findViewById(R.id.personname);

        Typeface nhp = Typeface.createFromAsset(getAssets(),
                "fonts/JosefinSans_Bold.ttf");
        WelcomeProceed.setTypeface(nhp);
        TVh.setTypeface(nhp);
        TVn.setTypeface(nhp);
        PersonNmae.setTypeface(nhp);


        PersonName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 0 && s.equals("")) {
                    WelcomeProceed.setBackground(getDrawable(R.drawable.roundgrey));
                   WelcomeProceed.setEnabled(false);
                } else {
                    WelcomeProceed.setBackground(getDrawable(R.drawable.round));
                    WelcomeProceed.setEnabled(true);

                    WelcomeProceed.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent i= new Intent(RegisterNameActivity.this,AvtarActivity.class);
                            startActivity(i);
                           // Toast.makeText(RegisterNameActivity.this, "string is  not empty", Toast.LENGTH_SHORT).show();
                        }
                    });


                }
            }
        });

        }
}
