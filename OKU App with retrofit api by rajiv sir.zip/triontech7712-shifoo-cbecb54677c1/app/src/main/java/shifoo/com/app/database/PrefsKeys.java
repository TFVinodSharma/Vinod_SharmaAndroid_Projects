package shifoo.com.app.database;

public interface PrefsKeys {

    String IS_USER_REGISTERED = "IS_USER_REGISTERED";
    String USER = "USER";
    String USER_TOKEN= "USER_TOKEN";

    String USER_LOGOUT="USER_LOGOUT";
   }
