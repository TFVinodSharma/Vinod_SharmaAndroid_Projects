package thuy.flickr

const val API_KEY = "ed3718658a013cfc67ea9b32d4bc5677"
