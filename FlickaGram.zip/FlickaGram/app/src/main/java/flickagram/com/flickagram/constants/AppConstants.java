package flickagram.com.flickagram.constants;

public interface AppConstants {

   // String BASE_URL = "https://api.flickr.com/services/";

        String BASE_URL="https://api.flickr.com/services/rest";
}
